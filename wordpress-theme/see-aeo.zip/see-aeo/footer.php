<?php
/**
 * Footer template — See AEO
 *
 * @package See_AEO
 */
?>

  <!-- FOOTER -->
  <footer class="footer">
    <div class="container footer__inner">
      <div class="footer__brand">
        <a href="#hero" class="brand-logo footer__logo" aria-label="See AEO">
          <span class="brand-logo__mark"><svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="7"/><path d="m21 21-3.5-3.5"/></svg></span>
          <span class="brand-logo__text">See<b>AEO</b></span>
        </a>
        <p class="footer__tagline">نُحوّل وجودك الرقمي إلى قوة لا تُقهر في نتائج البحث وإجابات الذكاء الاصطناعي.</p>
        <div class="social-links__icons" style="margin-top:18px;">
          <a href="#" class="social-link" aria-label="X"><svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg></a>
          <a href="#" class="social-link" aria-label="LinkedIn"><svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor"><path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433a2.062 2.062 0 01-2.063-2.065 2.064 2.064 0 112.063 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/></svg></a>
          <a href="#" class="social-link" aria-label="Instagram"><svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.052.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98C8.333 23.986 8.741 24 12 24c3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 100 12.324 6.162 6.162 0 000-12.324zM12 16a4 4 0 110-8 4 4 0 010 8zm6.406-11.845a1.44 1.44 0 100 2.881 1.44 1.44 0 000-2.881z"/></svg></a>
        </div>
      </div>
      <div class="footer__links-group"><h4 class="footer__heading">روابط سريعة</h4><ul class="footer__links"><li><a href="#hero">الرئيسية</a></li><li><a href="#services">خدماتنا</a></li><li><a href="#works">أعمالنا</a></li><li><a href="#about">من نحن</a></li><li><a href="#contact">تواصل معنا</a></li></ul></div>
      <div class="footer__links-group"><h4 class="footer__heading">خدماتنا</h4><ul class="footer__links"><li><a href="#services">SEO - تحسين محركات البحث</a></li><li><a href="#services">AEO - تحسين محركات الإجابة</a></li><li><a href="#services">GEO - التحسين الجغرافي</a></li><li><a href="#services">تصميم المواقع الاحترافية</a></li></ul></div>
      <div class="footer__links-group"><h4 class="footer__heading">تواصل معنا</h4><ul class="footer__links"><li><a href="mailto:hello@seeaeo.com">hello@seeaeo.com</a></li><li><a href="tel:+966500000000" dir="ltr">+966 50 000 0000</a></li><li><span>الرياض، المملكة العربية السعودية</span></li></ul></div>
    </div>
    <div class="footer__bottom"><div class="container"><p>© 2025 See AEO. جميع الحقوق محفوظة</p><div class="footer__bottom-links"><a href="#">سياسة الخصوصية</a><a href="#">الشروط والأحكام</a></div></div></div>
  </footer>

<?php wp_footer(); ?>
</body>
</html>
