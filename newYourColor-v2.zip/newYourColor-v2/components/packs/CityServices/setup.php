<?php 
class CityServices {
	function __construct() {
		$this->ThemeStatic = new ThemeStatic;
	}
	public function QueryEndpoint() {
		add_rewrite_endpoint( get_option('services_url'), EP_ROOT );
	}
	public function GetCurrentTerm($var) {
		$slug = $var;
		$var = urldecode($var);
		$var = str_replace('-', ' ', $var);
		$categories = get_terms(
			array(
				"taxonomy"	=> 'category',
				"hide_empty"=> false
			)
		);
		$cities = get_terms(
			array(
				"taxonomy"	=> 'country',
				"hide_empty"=> false
			)
		);
		$SelectedCategory = false;
		$SelectedCity = false;
		foreach( $categories as $term ) {
			if( strpos($var, $term->name) !== false ) $SelectedCategory = $term;
		}
		foreach( $cities as $term ) {
			if( strpos($var, $term->name) !== false ) $SelectedCity = $term;
		}
		if( $SelectedCity != false and $SelectedCategory != false )  {
			return array("city"=>$SelectedCity, "category"=>$SelectedCategory);
		}
		return false;
	}
	public function ServiceQVar_title($category, $city) {
		$structure = get_option('services_url_structure');
		$structure = str_replace('{city}', $city->name, $structure);
		$structure = str_replace('{category}', $category->name, $structure);
		return $structure;
	}
	public function ServiceQVar($category, $city) {
		$structure = get_option('services_url_structure');
		$structure = str_replace('{city}', $city->name, $structure);
		$structure = str_replace('{category}', $category->name, $structure);
		$structure = trim($structure);

		return home_url('/'.get_option('services_url').'/'.str_replace(' ', '-', $structure));
	}
	public function CityServicesPage() {
		if($CityServices = get_query_var(get_option('services_url'))){
			if( $term = $this->GetCurrentTerm($CityServices) ) {
				$this->ThemeStatic->Blade("city-services", array("term"=>$term));
			}else {
				wp_redirect(home_url(), 301);
			}
	    	die();
	    }
	}
	public function Setup() {
		add_action( 'init', array( $this, 'QueryEndpoint' ) );
		add_action( 'BeforeHeader', array( $this, 'CityServicesPage' ) );
	}
}
(new CityServices)->Setup();